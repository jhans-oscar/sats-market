from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import httpx
import time
from typing import Dict, Optional
from config import *

app = FastAPI(title="Sats Market API", version="1.0.0")

# CORS para desarrollo
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Cache simple en memoria
cache = {}

async def get_btc_price() -> float:
    """Obtiene precio actual de BTC en USD"""
    cache_key = "btc_price"
    
    if cache_key in cache:
        data, timestamp = cache[cache_key]
        if time.time() - timestamp < CACHE_DURATION:
            return data
    
    try:
        async with httpx.AsyncClient() as client:
            # Intenta CoinGecko primero
            response = await client.get(
                COINGECKO_API,
                params={"ids": "bitcoin", "vs_currencies": "usd"},
                timeout=10.0
            )
            if response.status_code == 200:
                btc_price = response.json()["bitcoin"]["usd"]
                cache[cache_key] = (btc_price, time.time())
                return btc_price
    except:
        pass
    
    # Fallback a Coinbase
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(COINBASE_API, timeout=10.0)
            if response.status_code == 200:
                btc_price = float(response.json()["data"]["amount"])
                cache[cache_key] = (btc_price, time.time())
                return btc_price
    except:
        raise HTTPException(status_code=503, detail="No se pudo obtener precio de BTC")

async def get_stock_price(ticker: str) -> Dict:
    """Obtiene precio de acción desde Yahoo Finance"""
    cache_key = f"stock_{ticker.upper()}"
    
    if cache_key in cache:
        data, timestamp = cache[cache_key]
        if time.time() - timestamp < CACHE_DURATION:
            return data
    
    url = f"{YAHOO_FINANCE_BASE}{ticker.upper()}"
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(url, timeout=10.0)
            if response.status_code != 200:
                raise HTTPException(status_code=404, detail=f"Ticker {ticker} no encontrado")
            
            data = response.json()
            result = data["chart"]["result"][0]
            
            # Extraer datos relevantes
            meta = result["meta"]
            current_price = meta["regularMarketPrice"]
            
            stock_data = {
                "symbol": meta["symbol"],
                "price_usd": current_price,
                "currency": meta["currency"],
                "exchange": meta["exchangeName"],
                "timestamp": meta["regularMarketTime"]
            }
            
            cache[cache_key] = (stock_data, time.time())
            return stock_data
            
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error obteniendo datos: {str(e)}")

@app.get("/")
async def root():
    return {
        "message": "Sats Market API 🧡⚡",
        "version": "1.0.0",
        "endpoints": {
            "price": "/api/price/{ticker}",
            "btc": "/api/btc",
            "search": "/api/search/{query} (próximamente)"
        }
    }

@app.get("/api/btc")
async def get_btc():
    """Endpoint para obtener precio de BTC"""
    btc_price = await get_btc_price()
    return {
        "btc_price_usd": btc_price,
        "timestamp": time.time()
    }

@app.get("/api/price/{ticker}")
async def get_price(ticker: str):
    """
    Obtiene precio de una acción en USD, BTC y Sats
    Ejemplo: /api/price/AAPL
    """
    # Obtener precio de la acción
    stock_data = await get_stock_price(ticker)
    
    # Obtener precio de BTC
    btc_price = await get_btc_price()
    
    # Calcular conversiones
    price_usd = stock_data["price_usd"]
    price_btc = price_usd / btc_price
    price_sats = price_btc * SATS_PER_BTC
    
    return {
        "symbol": stock_data["symbol"],
        "exchange": stock_data["exchange"],
        "price_usd": round(price_usd, 2),
        "price_btc": round(price_btc, 8),
        "price_sats": int(price_sats),
        "btc_rate": round(btc_price, 2),
        "timestamp": stock_data["timestamp"],
        "formatted_sats": f"{int(price_sats):,}"
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": time.time()}
