import os
from dotenv import load_dotenv

load_dotenv()

# APIs (no requieren key para uso básico)
YAHOO_FINANCE_BASE = "https://query1.finance.yahoo.com/v8/finance/chart/"
COINGECKO_API = "https://api.coingecko.com/api/v3/simple/price"
COINBASE_API = "https://api.coinbase.com/v2/prices/BTC-USD/spot"

# Configuración
CACHE_DURATION = 60  # segundos
SATS_PER_BTC = 100_000_000
