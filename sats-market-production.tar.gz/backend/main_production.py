from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import httpx
import time
import os
from typing import Dict
from config import *

app = FastAPI(title="Sats Market API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

cache = {}

async def get_btc_price() -> float:
    """Obtiene precio actual de BTC en USD"""
    cache_key = "btc_price"
    
    if cache_key in cache:
        data, timestamp = cache[cache_key]
        if time.time() - timestamp < CACHE_DURATION:
            return data
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                COINGECKO_API,
                params={"ids": "bitcoin", "vs_currencies": "usd"},
                timeout=10.0
            )
            if response.status_code == 200:
                btc_price = response.json()["bitcoin"]["usd"]
                cache[cache_key] = (btc_price, time.time())
                return btc_price
    except:
        pass
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(COINBASE_API, timeout=10.0)
            if response.status_code == 200:
                btc_price = float(response.json()["data"]["amount"])
                cache[cache_key] = (btc_price, time.time())
                return btc_price
    except:
        raise HTTPException(status_code=503, detail="No se pudo obtener precio de BTC")

async def get_stock_price(ticker: str) -> Dict:
    """Obtiene precio de acción desde Finnhub"""
    cache_key = f"stock_{ticker.upper()}"
    
    if cache_key in cache:
        data, timestamp = cache[cache_key]
        if time.time() - timestamp < CACHE_DURATION:
            return data
    
    url = FINNHUB_API
    params = {
        "symbol": ticker.upper(),
        "token": FINNHUB_API_KEY
    }
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(url, params=params, timeout=10.0)
            
            if response.status_code != 200:
                raise HTTPException(status_code=404, detail=f"Error obteniendo {ticker}")
            
            data = response.json()
            
            if "c" not in data or data["c"] == 0:
                raise HTTPException(status_code=404, detail=f"Ticker {ticker} no encontrado o mercado cerrado")
            
            current_price = data["c"]
            
            stock_data = {
                "symbol": ticker.upper(),
                "price_usd": float(current_price),
                "currency": "USD",
                "exchange": "US Market",
                "timestamp": int(time.time())
            }
            
            cache[cache_key] = (stock_data, time.time())
            return stock_data
            
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

# API Endpoints
@app.get("/api")
async def api_root():
    return {
        "message": "Sats Market API 🧡⚡",
        "version": "1.0.0",
        "endpoints": {
            "price": "/api/price/{ticker}",
            "btc": "/api/btc",
            "health": "/api/health"
        }
    }

@app.get("/api/btc")
async def get_btc():
    """Endpoint para obtener precio de BTC"""
    btc_price = await get_btc_price()
    return {
        "btc_price_usd": btc_price,
        "timestamp": time.time()
    }

@app.get("/api/price/{ticker}")
async def get_price(ticker: str):
    """
    Obtiene precio de una acción en USD, BTC y Sats
    Ejemplo: /api/price/AAPL
    """
    stock_data = await get_stock_price(ticker)
    btc_price = await get_btc_price()
    
    price_usd = stock_data["price_usd"]
    price_btc = price_usd / btc_price
    price_sats = price_btc * SATS_PER_BTC
    
    return {
        "symbol": stock_data["symbol"],
        "exchange": stock_data["exchange"],
        "price_usd": round(price_usd, 2),
        "price_btc": round(price_btc, 8),
        "price_sats": int(price_sats),
        "btc_rate": round(btc_price, 2),
        "timestamp": stock_data["timestamp"],
        "formatted_sats": f"{int(price_sats):,}"
    }

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": time.time()}

# Serve static files (frontend) in production
frontend_path = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.exists(frontend_path):
    app.mount("/static", StaticFiles(directory=frontend_path), name="static")
    
    @app.get("/{filename:path}")
    async def serve_frontend(filename: str):
        if filename.startswith("api"):
            return {"error": "Not found"}
        
        # Try to serve the file
        if filename in ["", "/"]:
            return FileResponse(os.path.join(frontend_path, "index.html"))
        
        file_path = os.path.join(frontend_path, filename)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            return FileResponse(file_path)
        
        # Fallback to index.html for SPA routing
        return FileResponse(os.path.join(frontend_path, "index.html"))
