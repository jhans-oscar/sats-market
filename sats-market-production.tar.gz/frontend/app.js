// Configuration
const API_URL = window.location.hostname === 'localhost' 
    ? 'http://localhost:8000/api'
    : '/api';
const WATCHLIST_KEY = 'satsmarket_watchlist';

// State
let currentUnit = 'sats';
let currentData = null;
let watchlist = loadWatchlist();

// Elements
const tickerInput = document.getElementById('tickerInput');
const btcTicker = document.getElementById('btcTicker');
const priceSection = document.getElementById('priceSection');
const loadingState = document.getElementById('loadingState');
const errorState = document.getElementById('errorState');
const watchlistGrid = document.getElementById('watchlistGrid');
const clearWatchlistBtn = document.getElementById('clearWatchlist');

// Initialize
init();

function init() {
    loadBTCPrice();
    renderWatchlist();
    setupEventListeners();
    
    // Refresh BTC price every minute
    setInterval(loadBTCPrice, 60000);
    
    // Refresh watchlist prices every 30 seconds
    setInterval(refreshWatchlist, 30000);
}

function setupEventListeners() {
    // Search on Enter
    tickerInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const ticker = tickerInput.value.trim().toUpperCase();
            if (ticker) searchTicker(ticker);
        }
    });

    // Unit toggle
    document.querySelectorAll('.unit-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            currentUnit = btn.dataset.unit;
            document.querySelectorAll('.unit-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            updatePriceDisplay();
        });
    });

    // Watchlist toggle
    const watchlistBtn = document.getElementById('watchlistBtn');
    watchlistBtn.addEventListener('click', toggleWatchlist);

    // Clear watchlist
    clearWatchlistBtn.addEventListener('click', () => {
        if (confirm('Remove all stocks from watchlist?')) {
            watchlist = [];
            saveWatchlist();
            renderWatchlist();
        }
    });
}

// API Calls
async function loadBTCPrice() {
    try {
        const response = await fetch(`${API_URL}/btc`);
        const data = await response.json();
        const price = new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(data.btc_price_usd);
        
        btcTicker.querySelector('.btc-price').textContent = price;
    } catch (err) {
        console.error('Error loading BTC price:', err);
    }
}

async function searchTicker(ticker) {
    showLoading();
    hideError();
    
    try {
        const response = await fetch(`${API_URL}/price/${ticker}`);
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || 'Failed to fetch data');
        }
        
        currentData = await response.json();
        displayPrice();
        tickerInput.value = '';
        
    } catch (err) {
        showError(err.message);
    } finally {
        hideLoading();
    }
}

function displayPrice() {
    document.getElementById('tickerSymbol').textContent = currentData.symbol;
    document.getElementById('exchangeBadge').textContent = currentData.exchange;
    
    updatePriceDisplay();
    updateWatchlistButton();
    
    priceSection.style.display = 'block';
    priceSection.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function updatePriceDisplay() {
    if (!currentData) return;
    
    const mainPrice = document.getElementById('mainPrice');
    const priceUnit = document.getElementById('priceUnit');
    
    switch (currentUnit) {
        case 'sats':
            mainPrice.textContent = formatNumber(currentData.price_sats);
            priceUnit.textContent = 'sats';
            break;
        case 'btc':
            mainPrice.textContent = currentData.price_btc.toFixed(8);
            priceUnit.textContent = '₿';
            break;
        case 'usd':
            mainPrice.textContent = formatCurrency(currentData.price_usd);
            priceUnit.textContent = '';
            break;
    }
    
    // Update conversions
    document.getElementById('conversionUSD').textContent = formatCurrency(currentData.price_usd);
    document.getElementById('conversionBTC').textContent = `₿${currentData.price_btc.toFixed(8)}`;
    document.getElementById('conversionSats').textContent = formatNumber(currentData.price_sats);
}

// Watchlist Functions
function toggleWatchlist() {
    if (!currentData) return;
    
    const btn = document.getElementById('watchlistBtn');
    const ticker = currentData.symbol;
    
    if (isInWatchlist(ticker)) {
        removeFromWatchlist(ticker);
        btn.classList.remove('active');
    } else {
        addToWatchlist(currentData);
        btn.classList.add('active');
    }
}

function addToWatchlist(data) {
    if (!isInWatchlist(data.symbol)) {
        watchlist.push({
            symbol: data.symbol,
            price_sats: data.price_sats,
            price_btc: data.price_btc,
            price_usd: data.price_usd,
            timestamp: Date.now()
        });
        saveWatchlist();
        renderWatchlist();
    }
}

function removeFromWatchlist(ticker) {
    watchlist = watchlist.filter(item => item.symbol !== ticker);
    saveWatchlist();
    renderWatchlist();
    updateWatchlistButton();
}

function isInWatchlist(ticker) {
    return watchlist.some(item => item.symbol === ticker);
}

function updateWatchlistButton() {
    if (!currentData) return;
    const btn = document.getElementById('watchlistBtn');
    if (isInWatchlist(currentData.symbol)) {
        btn.classList.add('active');
    } else {
        btn.classList.remove('active');
    }
}

function renderWatchlist() {
    if (watchlist.length === 0) {
        watchlistGrid.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">⭐</div>
                <p>Add stocks to your watchlist</p>
                <span class="empty-hint">Search for any ticker above</span>
            </div>
        `;
        clearWatchlistBtn.style.display = 'none';
        return;
    }
    
    clearWatchlistBtn.style.display = 'block';
    
    watchlistGrid.innerHTML = watchlist.map(item => `
        <div class="watchlist-card" onclick="searchTicker('${item.symbol}')">
            <div class="watchlist-card-header">
                <div class="watchlist-ticker">${item.symbol}</div>
                <button class="watchlist-remove" onclick="event.stopPropagation(); removeFromWatchlist('${item.symbol}')">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                </button>
            </div>
            <div class="watchlist-price">${formatNumber(item.price_sats)}</div>
            <div class="watchlist-unit">sats</div>
        </div>
    `).join('');
}

async function refreshWatchlist() {
    if (watchlist.length === 0) return;
    
    for (const item of watchlist) {
        try {
            const response = await fetch(`${API_URL}/price/${item.symbol}`);
            if (response.ok) {
                const data = await response.json();
                const index = watchlist.findIndex(w => w.symbol === item.symbol);
                if (index !== -1) {
                    watchlist[index] = {
                        symbol: data.symbol,
                        price_sats: data.price_sats,
                        price_btc: data.price_btc,
                        price_usd: data.price_usd,
                        timestamp: Date.now()
                    };
                }
            }
        } catch (err) {
            console.error(`Error refreshing ${item.symbol}:`, err);
        }
    }
    
    saveWatchlist();
    renderWatchlist();
}

// LocalStorage
function saveWatchlist() {
    localStorage.setItem(WATCHLIST_KEY, JSON.stringify(watchlist));
}

function loadWatchlist() {
    try {
        const data = localStorage.getItem(WATCHLIST_KEY);
        return data ? JSON.parse(data) : [];
    } catch {
        return [];
    }
}

// UI State
function showLoading() {
    loadingState.style.display = 'flex';
    priceSection.style.display = 'none';
}

function hideLoading() {
    loadingState.style.display = 'none';
}

function showError(message) {
    document.getElementById('errorMessage').textContent = message;
    errorState.style.display = 'block';
    setTimeout(() => {
        errorState.style.display = 'none';
    }, 5000);
}

function hideError() {
    errorState.style.display = 'none';
}

// Formatters
function formatNumber(num) {
    return new Intl.NumberFormat('en-US').format(num);
}

function formatCurrency(num) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(num);
}
